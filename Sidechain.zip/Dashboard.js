var http = require('http');
var url = require('url');
const fs = require("fs");
const Web3 = require('web3');
const Tx = require('ethereumjs-tx');


//global node parameters
var myAddress = '0xC14BbA1b6CC582BBB6B554a5c0821C619CFD42c4';
var privateKey = Buffer.from('099e8dc1316d838865648e3df3698e7a2037b6c81f270cc075a415b4a8ca6270', 'hex')
var mainnetUrl = "ws://localhost:8546"

var web3_main = new Web3.providers.WebsocketProvider(mainnetUrl);
var web3_side;
var bridge_main;
var bridge_side;

const web3 = new Web3(web3_main);

// contracts json contains compiled bridge contract
let source = fs.readFileSync("contracts.json");
let contracts = JSON.parse(source)["contracts"];

let abi = JSON.parse(contracts.BridgeMain.abi);
let code = '0x' + contracts.BridgeMain.bin;

// user input parameters
var nodeUrl = "";
var nodeAddress = "";

function displayPage(filename, res, datacallback) {
    fs.readFile(filename, function(err, data) {
        if (err) {
          res.writeHead(404, {'Content-Type': 'text/html'});
          return res.end("404 Not Found");
        }  
        if (datacallback) {
            data = datacallback(data);
        }
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        return res.end();
    });
}

function replaceBuffer(buffer, find, replace) {
    var index = buffer.indexOf(find)
    if (index == -1) {
        return null;
    }
    var target = Buffer.alloc(buffer.length + (replace.length - find.length));
    buffer.copy(target, 0, 0, index);
    replace.copy(target, index, 0, replace.length);
    buffer.copy(target, index + replace.length, index + find.length, buffer.length);
    return target;
}

function setNodeData(data) {
    data = replaceBuffer(data, Buffer.from("/*<nodeURLValue>*/"), Buffer.from("nodeURLValue=\"" + nodeUrl + "\""));
    data = replaceBuffer(data, Buffer.from("/*<nodeAddressValue>*/"), Buffer.from("nodeAddressValue=\"" + nodeAddress + "\""));
    return data;
}

async function deployContract(web3_provider, code, deployer, key) {
    web3.eth.setProvider(web3_provider);
    console.log("Deploying the bridge contract");
    let nonce = await web3.eth.getTransactionCount(deployer);
    const rawTx = {
        nonce: nonce,
        from: deployer,
        data: code,
        gasPrice: '0x09184e72a000',
        gasLimit: '0x5AA710',
      };
    const tx = new Tx(rawTx);
    tx.sign(key);
    let receipt = await web3.eth.sendSignedTransaction('0x' + tx.serialize().toString('hex'))
    return receipt.contractAddress;
}

async function createBridge(req, res) {
    nodeUrl = req.query.url;

    web3_side = new Web3.providers.WebsocketProvider(nodeUrl);

    bridge_main = await deployContract(web3_main, code, myAddress, privateKey);
    bridge_side = await deployContract(web3_side, code, myAddress, privateKey);

    nodeAddress = bridge_side;
    return displayPage("./Dashboard.html", res, setNodeData)
}

function selectAction(req, res) {
    switch (req.pathname) {
        case "":
        case "/":
            return displayPage("./Dashboard.html", res);
        case "/create_bridge":
            return createBridge(req, res);
        case "/create_token":
            return createToken(req);
        default:
            return displayPage("." + req.pathname, res)
    }
}

http.createServer(function (req, res) {
    var q = url.parse(req.url, true);
    return selectAction(q, res);
}).listen(8080);