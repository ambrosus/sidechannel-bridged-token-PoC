const Web3 = require('web3');
const fs = require("fs");
const Tx = require('ethereumjs-tx');
//global params
var myAddress = '0xC14BbA1b6CC582BBB6B554a5c0821C619CFD42c4';
var privateKey = Buffer.from('099e8dc1316d838865648e3df3698e7a2037b6c81f270cc075a415b4a8ca6270', 'hex')
var deployContracts = false;
var bridge_main = "0xd7f697affabe8f888e0b42dc0e6eba262b073218";
var bridge_side = "0xd7f697affabe8f888e0b42dc0e6eba262b073218";
var main = 'ws://localhost:8546';
var side = 'ws://localhost:8548';

const web3_main = new Web3.providers.WebsocketProvider(main);
const web3_side = new Web3.providers.WebsocketProvider(side);
const web3 = new Web3(web3_main);

// contracts json contains compiled bridge contract
let source = fs.readFileSync("contracts.json");
let contracts = JSON.parse(source)["contracts"];

let abi = JSON.parse(contracts.BridgeMain.abi);
let code = '0x' + contracts.BridgeMain.bin;

// deploy the bridge;
async function deployContract(web3_provider, code, deployer, key) {
    web3.eth.setProvider(web3_provider);
    console.log("Deploying the bridge contract");
    let nonce = await web3.eth.getTransactionCount(deployer);
    const rawTx = {
        nonce: nonce,
        from: deployer,
        data: code,
        gasPrice: '0x09184e72a000',
        gasLimit: '0x5AA710',
      };
    const tx = new Tx(rawTx);
    tx.sign(key);
    let receipt = await web3.eth.sendSignedTransaction('0x' + tx.serialize().toString('hex'))
    return receipt.contractAddress;
}

async function run() {
    if (deployContracts) {
        bridge_main = await deployContract(web3_main, code, myAddress, privateKey);
        bridge_side = await deployContract(web3_side, code, myAddress, privateKey);
    }
    console.log(bridge_main)
    console.log(bridge_side)
    // start listening for events;
    web3.eth.setProvider(web3_main);
    let bridge = web3.eth.Contract(abi, bridge_main);
    let subscription = bridge.events.Message().on('data', (event) => {
        console.log("Event:");
        console.log("Data:", event.returnValues.data);
        console.log("From:", event.returnValues.sender);
        console.log("To:", event.returnValues.recipient);
    });
    return subscription;
}
run();
/*
run().then(subscription => {
    //console.log('Press any key to exit');
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', () => {
        subscription.unsubscribe((error, success) => {
            if (success) {
                console.log('Successfully unsubscribed!');
            }
        });
        process.exit.bind(process, 0);
    });
})
.catch(err => {
    console.log(err);
});
*/